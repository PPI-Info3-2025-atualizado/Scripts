using UnityEngine;
using UnityEditor;

public class SunAssignerEditor : EditorWindow
{
    private GameObject sun;

    [MenuItem("Tools/Atribuir Sol aos Planetas")]
    public static void ShowWindow()
    {
        GetWindow<SunAssignerEditor>("Atribuidor de Sol");
    }

    void OnGUI()
    {
        GUILayout.Label("Atribuir automaticamente o Sol aos planetas", EditorStyles.boldLabel);

        sun = (GameObject)EditorGUILayout.ObjectField("Sol", sun, typeof(GameObject), true);

        if (GUILayout.Button("Atribuir Sun para todos os PlanetOrbit"))
        {
            if (sun == null)
            {
                Debug.LogError("Voc� precisa arrastar o objeto do Sol aqui.");
                return;
            }

            PlanetOrbit[] planets = FindObjectsOfType<PlanetOrbit>();
            int count = 0;

            foreach (PlanetOrbit planet in planets)
            {
                Undo.RecordObject(planet, "Assign Sun");
                planet.sun = sun.transform;
                EditorUtility.SetDirty(planet);
                count++;
            }

            Debug.Log($"Atribu�do o Sol para {count} planetas.");
        }
    }
}

