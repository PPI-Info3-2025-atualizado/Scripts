﻿using UnityEngine;

public class CameraFocusController : MonoBehaviour
{
    public Transform[] planets;
    public float focusSpeed = 2f;
    public Vector3 offset = new Vector3(0, 5f, -12f); // ← aqui ajusta a suavidade do ângulo

    private int currentPlanetIndex = 0;

    void Update()
    {
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll > 0f)
        {
            currentPlanetIndex = (currentPlanetIndex + 1) % planets.Length;
        }
        else if (scroll < 0f)
        {
            currentPlanetIndex = (currentPlanetIndex - 1 + planets.Length) % planets.Length;
        }

        if (planets.Length > 0 && planets[currentPlanetIndex] != null)
        {
            Vector3 targetPosition = planets[currentPlanetIndex].position + offset;
            transform.position = Vector3.Lerp(transform.position, targetPosition, Time.deltaTime * focusSpeed);
            transform.LookAt(planets[currentPlanetIndex]);
        }
    }
}
