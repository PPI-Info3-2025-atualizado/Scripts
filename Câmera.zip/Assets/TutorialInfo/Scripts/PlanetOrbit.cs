
using UnityEngine;

public class PlanetOrbit : MonoBehaviour
{
    public Transform sun;       // O Sol (centro)
    public float orbitSpeed = 10f;
    public float orbitDistance = 5f;

    private float angle;

    void Update()
    {
        angle += orbitSpeed * Time.deltaTime;
        float x = Mathf.Cos(angle) * orbitDistance;
        float z = Mathf.Sin(angle) * orbitDistance;
        transform.position = new Vector3(x, 0, z) + sun.position;
        transform.Rotate(Vector3.up * 20 * Time.deltaTime); // rota��o em si
    }
}

