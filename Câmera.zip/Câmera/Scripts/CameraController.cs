﻿using UnityEngine;

public class CameraController : MonoBehaviour
{
    public float moveSpeed = 10f;
    public float lookSpeed = 3f;
    public float scrollSpeed = 10f;

    private float yaw = 0f;
    private float pitch = 0f;

    void Update()
    {
        HandleMovement();
        HandleMouseLook();
        HandleScroll();
    }

    void HandleMovement()
    {
        Vector3 direction = Vector3.zero;

        // Movimento horizontal (WASD)
        if (Input.GetKey(KeyCode.W))
            direction += transform.forward;
        if (Input.GetKey(KeyCode.S))
            direction -= transform.forward;
        if (Input.GetKey(KeyCode.A))
            direction -= transform.right;
        if (Input.GetKey(KeyCode.D))
            direction += transform.right;

        // Movimento vertical (setas ↑ ↓)
        if (Input.GetKey(KeyCode.UpArrow))
            direction += Vector3.up;
        if (Input.GetKey(KeyCode.DownArrow))
            direction -= Vector3.up;

        transform.position += direction * moveSpeed * Time.deltaTime;
    }

    void HandleMouseLook()
    {
        if (Input.GetMouseButton(1)) // Botão direito do mouse
        {
            yaw += lookSpeed * Input.GetAxis("Mouse X");
            pitch -= lookSpeed * Input.GetAxis("Mouse Y");
            pitch = Mathf.Clamp(pitch, -89f, 89f);

            transform.rotation = Quaternion.Euler(pitch, yaw, 0f);
        }
    }

    void HandleScroll()
    {
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        transform.position += transform.forward * scroll * scrollSpeed;
    }
}
