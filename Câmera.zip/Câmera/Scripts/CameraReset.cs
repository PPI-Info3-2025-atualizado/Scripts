using UnityEngine;

public class CameraReset : MonoBehaviour
{
    public Transform targetObject; // Ex: Sol
    public Vector3 offset = new Vector3(0f, 10f, -20f); // posi��o relativa ao Sol
    public KeyCode resetKey = KeyCode.T;

    private Vector3 initialOffset;
    private Quaternion initialRotation;

    void Start()
    {
        if (targetObject != null)
        {
            // Guarda offset e rota��o iniciais
            initialOffset = offset;
            initialRotation = Quaternion.LookRotation(targetObject.position - (targetObject.position + offset));
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(resetKey) && targetObject != null)
        {
            // Define a posi��o e rota��o da c�mera com base no alvo
            transform.position = targetObject.position + initialOffset;
            transform.rotation = Quaternion.LookRotation(targetObject.position - transform.position);
        }
    }
}

