using System.Collections.Generic;
using UnityEngine;

public class SistemaSolar : MonoBehaviour
{
    [Header("Refer�ncia ao Sol")]
    public Transform sol; // Aqui a gente escolhe o objeto do Sol na cena

    [Header("Lista de planetas")]
    public List<Planeta> planetas; // Essa lista guarda todos os planetas que v�o girar

    [Header("Escala do sistema")]
    public float escalaOrbital = 1.0f; // Isso muda o tamanho das �rbitas (tipo zoom)

    void Update()
    {
        float deltaTime = Time.deltaTime; // Pega o tempo entre cada frame

        // Aqui a gente atualiza cada planeta do sistema solar
        foreach (var planeta in planetas)
        {
            planeta.Atualizar(sol.position, deltaTime, escalaOrbital);
        }
    }
}