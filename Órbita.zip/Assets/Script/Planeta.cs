using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Planeta
{
    public string nome; // Nome do planeta (s� pra identifica��o)

    public Transform planetaTransform; // Refer�ncia ao objeto do planeta na cena
    public float distanciaDoSol = 10f; // Dist�ncia do planeta at� o Sol
    public float velocidadeTranslacao = 10f; // Velocidade que o planeta gira em volta do Sol
    public float velocidadeRotacao = 50f; // Velocidade que ele gira em si mesmo

    [Header("Inclina��es")]
    public float inclinacaoOrbita = 0f; // Inclina��o da �rbita (tipo o plano da �rbita)
    public float inclinacaoAxial = 0f; // Inclina��o do pr�prio planeta

    [Header("Luas")]
    public List<Lua> luas; // Lista com as luas do planeta

    private float anguloTranslacao = 0f; // Guarda o �ngulo atual da rota��o em volta do Sol

    public void Atualizar(Vector3 posicaoSol, float deltaTime, float escala)
    {
        // Atualiza o �ngulo da �rbita com o tempo
        anguloTranslacao += velocidadeTranslacao * deltaTime;
        if (anguloTranslacao > 360f) anguloTranslacao -= 360f;

        // Cria a inclina��o da �rbita
        Quaternion rotacaoOrbita = Quaternion.Euler(inclinacaoOrbita, 0, 0);
        Vector3 direcao = Quaternion.Euler(0, anguloTranslacao, 0) * Vector3.forward;
        Vector3 novaPosicao = rotacaoOrbita * direcao * distanciaDoSol * escala;

        planetaTransform.position = posicaoSol + novaPosicao; // Define a nova posi��o do planeta

        // Faz o planeta girar em si mesmo com inclina��o axial
        Vector3 eixoRotacao = Quaternion.Euler(inclinacaoAxial, 0, 0) * Vector3.up;
        planetaTransform.Rotate(eixoRotacao, velocidadeRotacao * deltaTime);

        // Atualiza as luas do planeta
        foreach (var lua in luas)
        {
            lua.Atualizar(planetaTransform.position, deltaTime, escala);
        }
    }
}