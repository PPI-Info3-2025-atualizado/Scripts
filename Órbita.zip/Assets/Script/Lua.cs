using UnityEngine;

[System.Serializable]
public class Lua
{
    public string nome; // Nome da lua

    public Transform luaTransform; // Refer�ncia ao objeto da lua
    public float distanciaDoPlaneta = 2f; // Dist�ncia da lua at� o planeta
    public float velocidadeOrbital = 30f; // Velocidade que ela gira em volta do planeta
    public float velocidadeRotacao = 20f; // Velocidade da rota��o da lua

    [Header("Inclina��es")]
    public float inclinacaoOrbita = 0f; // Inclina��o da �rbita da lua
    public float inclinacaoAxial = 0f; // Inclina��o da rota��o da lua

    private float anguloOrbital = 0f; // Guarda o �ngulo da lua em volta do planeta

    public void Atualizar(Vector3 posicaoPlaneta, float deltaTime, float escala)
    {
        anguloOrbital += velocidadeOrbital * deltaTime;
        if (anguloOrbital > 360f) anguloOrbital -= 360f;

        Quaternion rotacaoOrbita = Quaternion.Euler(inclinacaoOrbita, 0, 0);
        Vector3 direcao = Quaternion.Euler(0, anguloOrbital, 0) * Vector3.forward;
        Vector3 novaPosicao = rotacaoOrbita * direcao * distanciaDoPlaneta * escala;

        luaTransform.position = posicaoPlaneta + novaPosicao;

        // Faz a lua girar em si mesma com inclina��o
        Vector3 eixoRotacao = Quaternion.Euler(inclinacaoAxial, 0, 0) * Vector3.up;
        luaTransform.Rotate(eixoRotacao, velocidadeRotacao * deltaTime);
    }
}