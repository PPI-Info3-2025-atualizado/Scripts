using System.Collections.Generic;
using UnityEngine;

public class SistemaSolar : MonoBehaviour
{
    [Header("Refer�ncia ao Sol")]
    public Transform sol;

    [Header("Planetas do Sistema")]
    public List<Planeta> planetas;

    [Header("Escala Orbital")]
    [Range(0.1f, 10f)]
    public float escalaOrbital = 1.0f;

    void Update()
    {
        if (sol == null) return;

        float deltaTime = Time.deltaTime;

        foreach (var planeta in planetas)
        {
            planeta?.Atualizar(sol.position, deltaTime, escalaOrbital);
        }
    }
}