using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Planeta
{
    public string nome;

    public Transform planetaTransform;
    public float distanciaDoSol = 10f;
    public float velocidadeTranslacao = 10f;
    public float velocidadeRotacao = 50f;

    [Header("Inclina��es")]
    public float inclinacaoOrbita = 0f;
    public float inclinacaoAxial = 0f;

    [Header("Luas")]
    public List<Lua> luas;

    private float anguloTranslacao = 0f;

    public void Atualizar(Vector3 posicaoSol, float deltaTime, float escala)
    {
        if (planetaTransform == null) return;

        // Atualiza o �ngulo orbital
        anguloTranslacao = Mathf.Repeat(anguloTranslacao + velocidadeTranslacao * deltaTime, 360f);

        // Calcula a posi��o em �rbita com inclina��o
        Quaternion rotacaoOrbita = Quaternion.Euler(inclinacaoOrbita, 0, 0);
        Vector3 direcao = Quaternion.Euler(0, anguloTranslacao, 0) * Vector3.forward;
        Vector3 novaPosicao = rotacaoOrbita * direcao * distanciaDoSol * escala;

        planetaTransform.position = posicaoSol + novaPosicao;

        // Rota��o axial
        Vector3 eixoRotacao = Quaternion.Euler(inclinacaoAxial, 0, 0) * Vector3.up;
        planetaTransform.Rotate(eixoRotacao, velocidadeRotacao * deltaTime);

        // Atualiza luas
        foreach (var lua in luas)
        {
            lua?.Atualizar(planetaTransform.position, deltaTime, escala);
        }
    }
}