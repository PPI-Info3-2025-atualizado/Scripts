using UnityEngine;

[System.Serializable]
public class Lua
{
    public string nome;

    public Transform luaTransform;
    public float distanciaDoPlaneta = 2f;
    public float velocidadeOrbital = 30f;
    public float velocidadeRotacao = 20f;

    [Header("Inclina��es")]
    public float inclinacaoOrbita = 0f;
    public float inclinacaoAxial = 0f;

    [Header("Rota��o Avan�ada")]
    public bool usarRotacaoAvancada = false;

    private float anguloOrbital = 0f;

    public void Atualizar(Vector3 posicaoPlaneta, float deltaTime, float escala)
    {
        if (luaTransform == null) return;

        // Atualiza �ngulo orbital
        anguloOrbital = Mathf.Repeat(anguloOrbital + velocidadeOrbital * deltaTime, 360f);

        // Calcula posi��o orbital
        Quaternion rotacaoOrbita = Quaternion.Euler(inclinacaoOrbita, 0, 0);
        Vector3 direcao = Quaternion.Euler(0, anguloOrbital, 0) * Vector3.forward;
        Vector3 novaPosicao = rotacaoOrbita * direcao * distanciaDoPlaneta * escala;

        luaTransform.position = posicaoPlaneta + novaPosicao;

        if (usarRotacaoAvancada)
        {
            // Direciona o eixo Z da lua para longe do planeta
            Vector3 direcaoOposta = (luaTransform.position - posicaoPlaneta).normalized;
            Quaternion rotacaoParaEspaco = Quaternion.LookRotation(direcaoOposta, Vector3.up);
            rotacaoParaEspaco *= Quaternion.Euler(0, 0, inclinacaoAxial);

            luaTransform.rotation = rotacaoParaEspaco;

            // Rota��o em torno do eixo Z
            luaTransform.Rotate(Vector3.forward, velocidadeRotacao * deltaTime, Space.Self);
        }
        else
        {
            // Rota��o simples com inclina��o axial
            Vector3 eixoRotacao = Quaternion.Euler(inclinacaoAxial, 0, 0) * Vector3.up;
            luaTransform.Rotate(eixoRotacao, velocidadeRotacao * deltaTime);
        }
    }
}