using UnityEngine;

public class OrbitController : MonoBehaviour
{
    [Header("Configura��es da �rbita")]
    [Tooltip("O objeto em torno do qual este objeto ir� orbitar (o Sol).")]
    public Transform centroDaOrbita; // Arraste o objeto "Sol" aqui pelo Inspector

    [Tooltip("Velocidade da transla��o (graus por segundo).")]
    public float velocidadeOrbital = 10f;

    [Tooltip("Eixo em torno do qual a �rbita ocorrer� (geralmente Vector3.up para uma �rbita 'plana').")]
    public Vector3 eixoOrbital = Vector3.up; // (0, 1, 0) - orbita no plano XZ

    [Header("Configura��es de Rota��o Axial (Opcional)")]
    [Tooltip("Velocidade da rota��o do pr�prio planeta (graus por segundo). Deixe 0 se n�o quiser rota��o.")]
    public float velocidadeRotacaoAxial = 5f;

    [Tooltip("Eixo em torno do qual o planeta rotaciona sobre si mesmo.")]
    public Vector3 eixoRotacaoAxial = Vector3.up;

    void Update()
    {
        // --- Transla��o (�rbita) ---
        if (centroDaOrbita != null)
        {
            // Faz este objeto (Merc�rio) girar em torno do 'centroDaOrbita' (Sol)
            // Par�metros:
            // 1. Ponto central da rota��o (posi��o do Sol)
            // 2. Eixo em torno do qual girar (ex: Vector3.up para orbitar no plano XZ)
            // 3. �ngulo para girar nesta frame (velocidade * tempo)
            transform.RotateAround(centroDaOrbita.position, eixoOrbital.normalized, velocidadeOrbital * Time.deltaTime);
        }
        else
        {
            Debug.LogWarning("Centro da �rbita n�o definido para " + gameObject.name);
        }

        // --- Rota��o Axial (Giro do Planeta em seu pr�prio eixo) ---
        if (velocidadeRotacaoAxial != 0)
        {
            // Faz este objeto girar em torno do seu pr�prio eixo local
            transform.Rotate(eixoRotacaoAxial.normalized, velocidadeRotacaoAxial * Time.deltaTime, Space.Self);
        }
    }

    // Opcional: Desenhar uma representa��o da �rbita no Editor para visualiza��o
    void OnDrawGizmosSelected()
    {
        if (centroDaOrbita != null)
        {
            // Desenha um c�rculo para representar a �rbita
            Gizmos.color = Color.gray;
            float distancia = Vector3.Distance(transform.position, centroDaOrbita.position);
            DrawOrbitPath(centroDaOrbita.position, eixoOrbital.normalized, distancia, 64);
        }
    }

    // Fun��o auxiliar para desenhar o caminho da �rbita
    void DrawOrbitPath(Vector3 center, Vector3 axis, float radius, int segments)
    {
        if (segments <= 0) return;
        Quaternion rotation = Quaternion.LookRotation(axis == Vector3.zero ? Vector3.forward : Vector3.Cross(axis, (Mathf.Abs(Vector3.Dot(axis, Vector3.up)) > 0.99f ? Vector3.right : Vector3.up)), axis); // Evita erro se axis for (0,1,0)
        Vector3 point = center + rotation * Vector3.forward * radius; // Ponto inicial no "equador" da �rbita

        Vector3 previousPoint = point;
        float angleStep = 360.0f / segments;

        for (int i = 1; i <= segments; i++)
        {
            Vector3 nextPoint = center + Quaternion.AngleAxis(angleStep * i, axis) * (point - center);
            Gizmos.DrawLine(previousPoint, nextPoint);
            previousPoint = nextPoint;
        }
    }
}

