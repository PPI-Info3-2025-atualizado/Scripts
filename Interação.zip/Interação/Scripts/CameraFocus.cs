using UnityEngine;

public class CameraFocus : MonoBehaviour
{
    public Transform target;       // Objeto a focar (ex: planeta)
    public float smoothSpeed = 5f; // Velocidade da transi��o
    public Vector3 offset = new Vector3(0, 5, -10); // Posi��o relativa � c�mera

    void LateUpdate()
    {
        if (target != null)
        {
            Vector3 desiredPosition = target.position + offset;
            transform.position = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed * Time.deltaTime);
            transform.LookAt(target);
        }
    }

    public void SetTarget(Transform newTarget)
    {
        target = newTarget;
    }
}