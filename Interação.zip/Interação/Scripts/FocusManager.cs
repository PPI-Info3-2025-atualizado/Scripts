using UnityEngine;

public class FocusManager : MonoBehaviour
{
    public CameraFocus cameraFocus;

    public Transform[] planetas; // Array com os 8 planetas
    private int planetaAtual = 0;

    void Start()
    {
        if (planetas.Length > 0)
            cameraFocus.SetTarget(planetas[planetaAtual]);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            planetaAtual = (planetaAtual + 1) % planetas.Length;
            cameraFocus.SetTarget(planetas[planetaAtual]);
        }
    }
}