using UnityEngine;

public class PlanetOrbit : MonoBehaviour
{
    public Transform sun; // Refer�ncia ao objeto do Sol
    public float orbitRadius = 10f; // Dist�ncia do planeta ao Sol
    public float orbitSpeed = 10f; // Velocidade de transla��o (graus por segundo)
    private float currentAngle; // �ngulo atual da �rbita

    void Update()
    {
        if (sun == null) return;

        // Atualiza o �ngulo com base no tempo e na velocidade
        currentAngle += orbitSpeed * Time.deltaTime;

        // Converte o �ngulo para posi��o ao redor do Sol
        float rad = currentAngle * Mathf.Deg2Rad;
        float x = sun.position.x + Mathf.Cos(rad) * orbitRadius;
        float z = sun.position.z + Mathf.Sin(rad) * orbitRadius;

        // Atualiza a posi��o do planeta
        transform.position = new Vector3(x, transform.position.y, z);
    }
}