using UnityEngine;

public class PlanetOrbit : MonoBehaviour
{
    [Header("Refer�ncias")]
    public Transform sunTransform; // Arraste o objeto Sol aqui

    [Header("Par�metros Orbitais")]
    public float orbitDistance = 10f;     // Dist�ncia m�dia do Sol (em unidades Unity)
    public float orbitSpeed = 10f;        // Velocidade de transla��o (graus por segundo)
    public float initialOrbitAngle = 0f;  // �ngulo inicial na �rbita (0 a 360 graus)
                                          // Permite que os planetas comecem em posi��es diferentes

    [Header("Par�metros de Rota��o (Pr�prio Eixo)")]
    public float rotationSpeed = 20f;     // Velocidade de rota��o no pr�prio eixo (graus por segundo)
    public Vector3 rotationAxis = Vector3.up; // Eixo de rota��o (pode ser inclinado para simular esta��es)

    [Header("Escala do Planeta")]
    public float planetScale = 1f;        // Multiplicador para o tamanho do planeta

    void Start()
    {
        if (sunTransform == null)
        {
            Debug.LogError("Sun Transform n�o foi atribu�do para " + gameObject.name + "! Desabilitando script.");
            enabled = false; // Desabilita o Update se o Sol n�o estiver configurado
            return;
        }

        // 1. Aplicar a escala ao planeta
        transform.localScale = Vector3.one * planetScale;

        // 2. Posicionar o planeta inicialmente na sua �rbita
        // Calcula a posi��o inicial baseada na dist�ncia e �ngulo inicial
        float angleRad = initialOrbitAngle * Mathf.Deg2Rad; // Converte graus para radianos
        Vector3 initialOffset = new Vector3(Mathf.Cos(angleRad) * orbitDistance,
                                            0, // Mant�m no plano XZ por simplicidade (pode ser ajustado)
                                            Mathf.Sin(angleRad) * orbitDistance);
        transform.position = sunTransform.position + initialOffset;
    }

    void Update()
    {
        if (sunTransform == null) return; // Seguran�a adicional

        // 1. Transla��o em torno do Sol
        // O planeta rotaciona em torno do ponto 'sunTransform.position',
        // ao redor do eixo 'Vector3.up' (eixo Y global),
        // com a velocidade 'orbitSpeed * Time.deltaTime'.
        transform.RotateAround(sunTransform.position, Vector3.up, orbitSpeed * Time.deltaTime);

        // 2. Rota��o no pr�prio eixo
        // O planeta rotaciona em torno do seu pr�prio 'rotationAxis'
        transform.Rotate(rotationAxis, rotationSpeed * Time.deltaTime, Space.Self);
    }
}